/** @type {import('next').NextConfig} */
const nextConfig = {
    unoptimized  : true
};

export default nextConfig;
